#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Signal.h"

int main() {
	SignalsList signals;
	signals.numberOfSignals = 0;
	char command[101], *pointerToToken, listOfParameters[100][100];
	int indexForTokens = 0;
	for (int i = 0; i < 101; i++)command[i] = 0;
	printf("Type down the command you want:\n");
	while (1)
	{
		indexForTokens = 0;
		printf("> ");
		scanf(" %[^'\n']s", command);
		if (strcmp(command, "exit")==0 || strcmp(command, "0")==0)break;
		pointerToToken = strtok(command, " ");
		while (pointerToToken){
			strcpy(listOfParameters[indexForTokens], pointerToToken);
			indexForTokens++;
			pointerToToken = strtok(NULL, " ");
		}
		if (strcmp(listOfParameters[0], "add") == 0 && indexForTokens == 5) {
			int success = addSignal(atoi(listOfParameters[1]), listOfParameters[2], listOfParameters[3], atoi(listOfParameters[4]), &signals);
			if (success == -1) printf("This signal already exist!\n");
		}
		else if (strcmp(listOfParameters[0], "update") == 0 && indexForTokens == 5) {
			int success = updateSignal(atoi(listOfParameters[1]), listOfParameters[2], listOfParameters[3], atoi(listOfParameters[4]), &signals);
			if (success == -1) printf("There is no signal with such id!\n");
		}
		else if (strcmp(listOfParameters[0], "delete") == 0 && indexForTokens == 2) {
			int success = deleteSignal(atoi(listOfParameters[1]), &signals);
			if (success == -1) printf("There is no signal with such id!\n");
		}
		else if (strcmp(listOfParameters[0], "list") == 0 && indexForTokens == 1)
			listSignals(signals);
		else if (strcmp(listOfParameters[0], "list") == 0 && indexForTokens == 2)
			listSignalsByType(listOfParameters[1], signals);
	}
	return 0;
}