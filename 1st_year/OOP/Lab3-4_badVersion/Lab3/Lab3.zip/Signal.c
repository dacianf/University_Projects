#include "Signal.h"
#include <stdio.h>


int searchSignalByID(int id, SignalsList *signalsList) {
	//Search by id if in the signals list exists a signal with given id
	//Input: id - positive integer
	//		 signalsList - list of signals
	//Output: i - integer representing position 
	//			- if in the list exists a signal with given id
	//		  -1 - otherwise
	for (int i = 0; i < signalsList->numberOfSignals; i++)
		if (signalsList->signals[i].id == id)
			return i;
	return -1;
}

void listSignals(SignalsList signalsList) {
	/*Prints on the screen evry signal from given list
	Input: signalsList - list of signals
	*/
	if (signalsList.numberOfSignals == 0)
		printf("There are no signals in the list!\n");
	else {
		printf("Signals are:\nID\tModulated Signal\tSignal type\tPriority number\n");
		for (int i = 0; i < signalsList.numberOfSignals; i++)
			printf("%-8d%-24s%-16s%-8d\n",
				signalsList.signals[i].id, signalsList.signals[i].modulatedSignal,
				signalsList.signals[i].type, signalsList.signals[i].priorityNumber);
	}
}

void listSignalsByType(char * type, SignalsList signalsList) {
	/*Prints on the screen evry signal from given list
	Input:	type - string of chars between (damage-inner, damage-outer, sensor-reading)
			signalsList - list of signals
	*/
	int numberOfSignalsFound = 0;
	for (int i = 0; i < signalsList.numberOfSignals; i++)
		if (strcmp(signalsList.signals[i].type, type) == 0) {
			if(numberOfSignalsFound==0)printf("Signals are:\nID\tModulated Signal\tSignal type\tPriority number\n");
			printf("%-8d%-24s%-16s%-8d\n",
				signalsList.signals[i].id, signalsList.signals[i].modulatedSignal,
				signalsList.signals[i].type, signalsList.signals[i].priorityNumber),
				numberOfSignalsFound++;
		}
	if (numberOfSignalsFound == 0)
		printf("There is no signal with type: %s.\n", type);
}

int copyFromASignalToAnother(Signal *destinationSignal, Signal *sourceSignal) {
	/*Copies from source signal into destination signal
	Input: destinationString - Signal
		   sourceSignal - Signal
	Output: 1 - after modification occured
	*/
	destinationSignal->id = sourceSignal->id;
	destinationSignal->priorityNumber = sourceSignal->priorityNumber;
	strcpy(destinationSignal->modulatedSignal, sourceSignal->modulatedSignal);
	strcpy(destinationSignal->type, sourceSignal->type);
	return 1;
}

int addSignal(int id, char *modulatedSignal, char *type, int priorityNumber, SignalsList *signalsList) {
	/*Add a given signal into signals list
	Input: id - positive integer
		   modulatedSignal - string of chars
		   type - string of chars (damage-inner, damage-outer, sensor-reading)
		   priorityNumber - positive integer
		   signalsList - list of signals
	Output: 1 - if operation succeded
			-1 - otherwise
	*/
	if (signalsList->numberOfSignals == 0 || searchSignalByID(id, signalsList) == -1) {
		signalsList->signals[signalsList->numberOfSignals].id = id;
		signalsList->signals[signalsList->numberOfSignals].priorityNumber = priorityNumber;
		strcpy(signalsList->signals[signalsList->numberOfSignals].modulatedSignal, modulatedSignal);
		strcpy(signalsList->signals[signalsList->numberOfSignals].type, type);
		signalsList->numberOfSignals++;
		return 1;
	}
	return -1;
}

int updateSignal(int id, char *newModulatedSignal, char *newType, int newPriorityNumber, SignalsList *signalsList) {
	/*Updates a signal info from signals list and finding it by id
	Input: id - positive integer
		   newModulatedSignal - string of chars
		   newType - string of chars (damage-inner, damage-outer, sensor-reading)
		   newPriorityNumber - positive integer
		   signalsList - list of signals
	Output: 1 - if operation succeded
			-1 - otherwise
	*/
	int signalPosition = searchSignalByID(id, signalsList);
	if (signalPosition == -1) return 0;
	strcpy(signalsList->signals[signalPosition].modulatedSignal, newModulatedSignal);
	strcpy(signalsList->signals[signalPosition].type, newType);
	signalsList->signals[signalPosition].priorityNumber = newPriorityNumber;
	return 1;
}

int deleteSignal(int id, SignalsList *signalsList) {
	/*Delets a signal from signals list
	Input: id - positive integer
		   signalsList - list of signals
	Output: 1 - if operation succeded
			-1 - otherwise
	*/
	int signalPosition = searchSignalByID(id, signalsList);
	if (signalPosition == -1) return -1;
	for (int i = signalPosition; i < signalsList->numberOfSignals; i++)
		copyFromASignalToAnother(&(signalsList->signals[i]), &(signalsList->signals[i + 1]));
	signalsList->numberOfSignals--;
	return 1;
}